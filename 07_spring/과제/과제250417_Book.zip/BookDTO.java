package org.zerock.dto;

import lombok.Data;

@Data
public class BookDTO {
	private String title;
	private String name;
	private String price;
	private String publisher;
}
