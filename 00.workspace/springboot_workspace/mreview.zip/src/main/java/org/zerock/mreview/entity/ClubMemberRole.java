package org.zerock.mreview.entity;

public enum ClubMemberRole {
  USER, MANAGER, ADMIN;
}
