package com.example.openai.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Map;

@Service
public class OpenAIService2 {        
    private WebClient webClient;

    public OpenAIService2(@Value("${openai.api.key}") String apiKey) {
        this.webClient = WebClient.builder()
                .baseUrl("https://api.openai.com/v1/chat/completions")
                .defaultHeader("Authorization", "Bearer " + apiKey)
                .defaultHeader("Content-Type", "application/json")
                .build();
    }

    public Mono<String> getChatCompletion(String userPrompt) {
        Map<String, Object> request = Map.of(
                "model", "gpt-4.1-nano",
                "messages", new Object[] {
                        Map.of("role", "system", "content", "너는 한국 관광 도우미야. 모든 답변은 간단한 자기소개 후에 해줘."),
                        Map.of("role", "user", "content", userPrompt)
                }
        );

        return webClient.post()
                .bodyValue(request)
                .retrieve()
                .bodyToMono(String.class);
    }
}
