package com.example.openai.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.openai.service.OpenAIService;
import com.example.openai.service.OpenAIService2;

import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/chat")
public class ChatController {

    @Autowired
    private OpenAIService openAIService;
    
    @Autowired
    private OpenAIService2 openAIService2;



    @GetMapping("/completions")
    public String getChatCompletions(String prompt) {
        return openAIService.getChatCompletion(prompt);
    }

    //WebClient방식. 추천
    @GetMapping("/completions2")
     public Mono<String> chat(String prompt) {
        return openAIService2.getChatCompletion(prompt);
    }
}