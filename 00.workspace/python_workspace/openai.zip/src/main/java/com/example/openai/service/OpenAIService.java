package com.example.openai.service;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;

@Service
public class OpenAIService {

    @Value("${openai.api.key}")
    private String apiKey;

    private final RestTemplate restTemplate;

    public OpenAIService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public String getChatCompletion(String prompt) {
        String url = "https://api.openai.com/v1/chat/completions";

        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(apiKey);
        headers.setContentType(MediaType.APPLICATION_JSON);

        String requestBody = String.format("""
                {
                    "model":"gpt-4.1-nano", 
                    "messages":[
                        {"role":"system", "content":"너는 한국 관광 도우미야. 모든 답변은 간단한 자기소개 후에 해줘."},
                        {"role":"user", "content":"%s"}
                    ]
                }                
                """,
                prompt);

        HttpEntity entity = new HttpEntity<>(requestBody, headers);

        ResponseEntity response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);

        return (String) response.getBody(); // 응답 본문 반환
    }
}
