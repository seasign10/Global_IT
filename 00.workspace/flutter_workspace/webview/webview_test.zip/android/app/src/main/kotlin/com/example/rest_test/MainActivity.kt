package com.example.webview_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
